﻿using System;
using System.Globalization;

namespace Curso
{
    class Program
    {
        static void Main(string[] args)
        {
            Conta conta;

            Console.WriteLine("Digite o número da conta:");
            int numero = int.Parse(Console.ReadLine());

            Console.WriteLine("Digite o nome do titular da conta:");
            string titular = Console.ReadLine();

            Console.WriteLine("Há saldo na conta? (S/N)");
            char depositoInicial = char.Parse(Console.ReadLine());

            if (depositoInicial == 's' || depositoInicial == 'S')
            {
                Console.WriteLine("Digite o valor do saldo da conta:");
                double saldo = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

                conta = new Conta(numero, titular, saldo);
            }
            else
            {
                conta = new Conta(numero, titular);
            }

            Console.WriteLine();
            Console.WriteLine("Dados da conta:");
            Console.WriteLine(conta);

            Console.Write("Digite o valor do depósito:");
            double deposito = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
            conta.Deposito(deposito);

            Console.WriteLine();
            Console.WriteLine("Dados da conta:");
            Console.WriteLine(conta);

            Console.Write("Digite o valor que deseja sacar:");
            double saque = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
            conta.Saque(saque);

            Console.WriteLine();
            Console.WriteLine("Dados da conta atualizados:");
            Console.WriteLine(conta);
        }
    }

}
