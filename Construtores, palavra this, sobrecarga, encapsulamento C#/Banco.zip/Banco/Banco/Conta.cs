﻿using System;
using System.Globalization;

namespace Curso
{
    class Conta
    {
        public int Numero { get; private set;}
        public string Titular { get; set;}
        public double Saldo { get; private set;}

        public Conta(int numero, string titular)
        {
            Numero = numero;
            Titular = titular;
        }

        public Conta(int numero, string titular, double saldo) : this(numero, titular)
        {
            Saldo = saldo;
        }

        public void Saque(double saque)
        {
           Saldo -= saque + 5.0;
        }

        public void Deposito(double deposito)
        {
            Saldo += deposito;
        }

        public override string ToString()
        {
            return "Titular: " + Titular.ToString() +
            " ,Número da conta: " + Numero
            + " ,Saldo: $" + Saldo.ToString("F2", CultureInfo.InvariantCulture);
        }
    }
}
