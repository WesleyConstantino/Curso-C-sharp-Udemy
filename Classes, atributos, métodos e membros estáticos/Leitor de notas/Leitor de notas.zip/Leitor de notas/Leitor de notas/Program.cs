﻿using System;
using System.Globalization;

namespace Course
{
    class Program
    {
        public static void Main(string[] args)
        {
            Aluno al = new Aluno();

            Console.WriteLine("Digite seu nome:");
            al.Nome = Console.ReadLine();

            Console.WriteLine("Digite a nota 1:");
            al.Nota1 = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

            Console.WriteLine("Digite a nota 2:");
            al.Nota2 = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

            Console.WriteLine("Digite a nota 3:");
            al.Nota3 = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);



            Console.WriteLine(al.Nome + ", sua média é " + al.CalculaNota().ToString("F2", CultureInfo.InvariantCulture) + ". Você está ");

            if (al.Aprovado())
            {
                Console.WriteLine("aprovado!");
            }
            else
            {
                Console.WriteLine("reprovado! A nota restante é: " + al.NotaRestante().ToString("F2", CultureInfo.InvariantCulture));
            }
        
        }
    }
}