﻿namespace Course
{
    class Funcionario
    {
        public string Nome;
        public double Salario;
    }
}