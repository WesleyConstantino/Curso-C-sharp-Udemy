﻿using System;

namespace Curso{
    class Program
    {
        public static void Main(string[] args)
        {

            Pessoa Maria, Joao;

            Maria = new Pessoa();
            Joao = new Pessoa();

            Console.WriteLine("Digite a idade de Maria:");
            Maria.Idade = int.Parse(Console.ReadLine());

            Console.WriteLine("Digite a idade de João:");
            Joao.Idade = int.Parse(Console.ReadLine());

            if(Maria.Idade < Joao.Idade)
            {
                Console.WriteLine("João é mais velho que Maria.");
            }
            else
            {
                Console.WriteLine("Maria é mais velha que João.");
            }
        }
    }
}